REIGN OF DOOM / ALPHA 2 — THE GREAT SIEGE UPDATE

Run: node scripts/serve.mjs
Open the local address printed by the server. Node 24 recommended.
No npm install or network access is required to play the built game.
Do not open index.html by double-clicking; serve it over HTTP.
See the in-game Field manual for controls.
