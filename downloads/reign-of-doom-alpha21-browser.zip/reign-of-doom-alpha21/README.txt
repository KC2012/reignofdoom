REIGN OF DOOM / ALPHA 2.1 — MOBILE-FIRST ARCADE RECOVERY

Run: node scripts/serve.mjs
Open the local address printed by the server. Node 24 recommended.
No npm install or network access is required to play the built game after loading.
Do not open index.html by double-clicking; serve it over HTTP.
For iPad on the same Wi-Fi, set HOST=0.0.0.0 before starting the server.
Use the tablet address printed in the terminal.
Two players starts immediately. Drag pieces; pull the ballista ring.

Safari/iPad hardware compatibility has not been verified in this environment.
See the complete package report for the tested configurations and limitations.
